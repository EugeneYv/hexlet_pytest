# Эта функция переворачивает переданную строку
def reverse(string):
#    return string[::-1]
    return string  # ломаем функцию

